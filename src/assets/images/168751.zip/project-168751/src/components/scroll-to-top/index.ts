export { default as ScrollToTop } from './scroll-to-top';
