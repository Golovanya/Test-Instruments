export const enum HeaderImageStyles {
    Widht = 63,
    Height = 63,
  }
