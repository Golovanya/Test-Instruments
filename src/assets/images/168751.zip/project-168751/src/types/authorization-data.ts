export interface AuthorizationData {
  email: string;
  password: string;
}
