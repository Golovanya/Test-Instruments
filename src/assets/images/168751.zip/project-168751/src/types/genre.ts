export const enum Genre {
  DefaultGenre = 'All genres',
}
