export const enum ReducerName {
  Authorzation = 'authorizationReducer',
  Main = 'mainReducer',
  Film = 'filmReducer'
}
