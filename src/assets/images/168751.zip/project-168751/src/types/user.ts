export interface User {
  avatarUrl: string;
  email: string;
  id: number;
  name: string;
  token: string;
}
