export const Actions = {
  SetGenre: '/setGenre',
  SetFilmsLoadStatus: '/setFilmsLoadStatus',
  SetFilms: '/setFilms',
  SetUser: '/setUser',
  SetAuthorizationStatus: '/setAuthorizationStatus',
  SetError: '/setError',
  SetReviews: '/setReviews',
} as const;
