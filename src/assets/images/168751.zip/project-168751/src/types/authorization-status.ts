export const enum AuthorizationStatus {
  Unauthorized = 'UnAuthorized',
  Authorized = 'Authorized',
  Idle = 'Idle'
}


